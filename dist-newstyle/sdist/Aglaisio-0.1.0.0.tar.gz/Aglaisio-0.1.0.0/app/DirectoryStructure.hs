module DirectoryStructure where

import System.Directory (doesDirectoryExist, listDirectory, doesFileExist)
import Control.Monad.Trans.Except
import Control.Monad.IO.Class (liftIO)
import Control.Monad (filterM)
import qualified Data.Set as S


data DirectoryStructure =
  DirectoryStructure {
    name :: FilePath,
    allDirs :: S.Set DirectoryStructure,
    allFiles :: S.Set FilePath
  }
  deriving Show


numOfFiles :: FilePath -> ExceptT String IO Int
numOfFiles dirname = do
  -- Check if the directory exists
  isDir <- liftIO $ doesDirectoryExist dirname
  if not isDir
    then throwE "This is not a directory!"
    else do
      -- List directory contents
      contents <- liftIO $ listDirectory dirname
      -- Filter files only
      files <- liftIO $ filterM doesFileExist (map (\f -> dirname ++ "/" ++ f) contents)
      -- Return the count of files
      return (length files)

fetchDirectoryStructure :: FilePath -> ExceptT String IO DirectoryStructure
fetchDirectoryStructure dirname =
  do
    isDir <- liftIO $ doesDirectoryExist dirname
    if not isDir then
      throwE $ dirname ++ " is not a directory!"
    else do
      contents <- liftIO $ listDirectory dirname
      files <- liftIO $ filterM doesFileExist $ map (\f -> dirname ++ "/" ++ f) contents
      dirs <- liftIO $ filterM doesDirectoryExist $ map (\d -> dirname ++ "/" ++ d) contents
      recursiveDirs <- traverse fetchDirectoryStructure dirs
      return $ DirectoryStructure dirname (S.fromList recursiveDirs) (S.fromList files)






